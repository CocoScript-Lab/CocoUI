Config = {}

Config.ShowCash = true           -- Show or hide the cash box
Config.ShowBank = true           -- Show or hide the bank box
Config.ShowBlackMoney = true     -- Show or hide the black money box (the item name for black money should be set as "black_money")
Config.ShowJob = true            -- Show or hide the job box
Config.ShowRank = true           -- Show or hide the job rank box
Config.ShowPlayerID = true       -- Show or hide the player ID box
